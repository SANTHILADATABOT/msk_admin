
<style type="text/css">
.style1 {font-weight:normal;font-family:calibri;font-size: 14px;}
.style2 {font-weight:normal;font-family:calibri;font-size: 16px;}
.style3 {font-weight:bold; text-align:right;font-family:calibri;font-size: 12px;}
.style4 {font-weight:bold; font-family:calibri;font-size: 16px;}
.style5 {font-family:calibri;font-weight: bold;font-size: 18px;}
.style6 {font-family:calibri;font-weight: bold;font-size: 16px;}
.style10{ border-top: solid 1px; border-top-color:#BFBFBF;}
.bottom{ border-bottom: solid 1px; border-bottom-color:#BFBFBF;}
.right{ border-right: solid 1px; border-bottom-color:#BFBFBF;}
</style>
<?php 
error_reporting(0);
session_start();
include ("../inc/commonfunction.php");

$cur_date=date('Y-m-d');

$wanted_data=$_REQUEST['wanted_data'];

$query='';


 function val_of_family_name($exp_val)
    {
        $i=1;
	    global $pdo_conn;
        $get_val=explode(",",$exp_val);
        $get_count=count($get_val);
        foreach($get_val as  $val_get)
        {
             if($i==$get_count) {$val_con="";  } else {$val_con=","; }
             $findrelationship = $pdo_conn->prepare("SELECT * From fact_finding_subform  where id='".$val_get."'");
             $findrelationship->execute();
             $fetrelationship_list = $findrelationship->fetch();
             $get_val_name.=$fetrelationship_list['family_head_name'].$val_con;
              $i++;
        }
    
      return   $get_val_name;
         
} 	 
?>
 


	

<div id="daybook_report_prints">
	<table width="100%" cellspacing="0" cellpadding="0">
         <tr>
			<td width="20px"><a href="../index.php"><img src="../images/logo.png" alt="image description" height="100px" class="style5"></a></td>
	
			<td height="37" align="center" class="style5"><?php echo $wanted_data;?> Surgery Needy</td>
	
		
        </tr>
	</table>
	<br>
    <table width="100%" cellspacing="0" cellpadding="0">
	
	  <tr>
            <td width="5%" height="27" align="center" class="style10 style4 right"><strong>S.No</strong></td>
            <td width="6%" align="center" class="style10 style4 right"><strong>&nbsp;F.No</strong></td>
			 <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Disease Details</strong></td>
            <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Surgery Disease Details</strong></td>
             <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Name(Surgery)</strong></td>
			<td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Mon Exp On Medicine</strong></td>
			<td width="14%" align="center" class="style10 style4 right bottom"><strong>&nbsp;Name(Mon Exp)</strong></td>
            <td width="14%" align="center" class="style10 style4 right bottom"><strong>&nbsp;Phone No</strong></td>
			
			 <td width="14%" align="center" class="style10 style4 right bottom"><strong>&nbsp;Apply</strong></td>
			
	  </tr>
        <tr>
		
				<td height="0" colspan="7" align="center" class="style10 style3 right" ></td>
        </tr>
        <?php 
	
		
	



$survey_sub_medical = $pdo_conn->prepare("SELECT DISTINCT a.country_id,a.district_id,a.state_id,a.city_id,a.area_id,a.survey_id,a.unique_no,a.family_no,b.disease_details,b.surgery_details,b.surgery_details_no,b.mon_exp_on_medicine,b.mon_exp_on_medicine_no,a.contact_no FROM  fact_family_disease b left join fact_finding_form a ON a.unique_no=b.unique_no WHERE  b.delete_status!='1' and a.user_id!='0' and a.delete_status!='1' ORDER BY a.survey_id DESC");
						

        
 $survey_sub_medical->execute();
 $med_survey_list_sub = $survey_sub_medical->fetchall();//echo "<pre>";print_r($survey_list_sub);echo "</pre>";
 if(!empty($med_survey_list_sub))
 {
         foreach ($med_survey_list_sub as $record1)
         {
              
                

 ?>
	
	<tr>
            	<td align="center" height="25" class="style2 right"><?php echo $i = $i+1; ?></td>
                <td align="center" class="style2 right">&nbsp;<?php echo $record1[family_no];?></td>

					<td align="center" class="style2 right">&nbsp;<?php echo $record1['disease_details']; ?></td>
						<td align="center" class="style2 right">&nbsp;<?php echo $record1[surgery_details]; ?></td>
						<td align="center" class="style2 right">&nbsp;<?php echo val_of_family_name($record1[surgery_details_no]); ?></td>
						<td align="center" class="style2 right">&nbsp;<?php echo $record1[mon_exp_on_medicine]; ?></td>
							<td align="center" class="style2 right ">&nbsp;<?php echo val_of_family_name($record1[mon_exp_on_medicine_no]); ?></td>
					
							<td align="center" class="style2 right ">&nbsp;<?php echo $record1[contact_no]; ?></td>
					
						
						<td align="center" class="style2 right ">&nbsp;<?php echo ""; ?></td>
					
					<?php
			}	}?>
				
	</tr>
		   

				<td colspan="10" align="right" class="style10 style1" >Printed Date :<?php echo $curdate=date('d-m-Y');?></td>
		
	
     
    </table>
</div>