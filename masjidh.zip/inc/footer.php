<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
		  <li class="nav-item">
			<a class="nav-link" href="https://santhila.co/" style="color:#00923a">Santhila</a>
		  </li>
		</ul>
    </div>
	  &copy; 2019 All rights reserved.
  </footer>