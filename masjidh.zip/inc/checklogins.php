<?php 
ob_start();
session_start();
	require_once('dbConnect.php');
	
	$login_name = $_POST['login_name'];
	$login_password = $_POST['login_password'];

	$select_usercreation=$pdo_conn->prepare("SELECT * FROM usercreation  WHERE 	username='$login_name' AND password='$login_password' ");
	$select_usercreation->execute();
	
	$checklogin = $select_usercreation->fetchAll();
	
	if(count($checklogin) > 0) 
	{	
		foreach($checklogin as $value) 
		{
			$_SESSION['usercreation_id'] = $value['user_id'];
			$_SESSION['full_name'] = $value['username'];
			$_SESSION['user_roll'] = $value['user_type'];			
		} 
		echo  "success";
	}
	else
	{
		echo "failed";
	}	

?>