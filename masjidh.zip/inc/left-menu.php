<aside class="main-sidebar">
    <!-- sidebar -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
		 <div class="ulogo">
			 <a href="index.php">
			  <!-- logo for regular state and mobile devices -->
			 
			    <img src="images/logo.png" alt="image description" >

			</a>
		<!-- </div>
        <div class="image">
          <a href="index.php"><img src="#" class="rounded-circle" alt="CK"></a>
        </div> -->
        
      </div>
      <!-- sidebar menu -->
      <ul class="sidebar-menu" data-widget="tree">
		<li class="nav-devider"></li>
        <li class="header nav-small-cap">MAIN NAVIGATION</li>
		<!-- <li class="treeview <?php echo $open; ?>">
          <a href="#"> 

	  <i class="fa fa-address-card icon-1" aria-hidden="true"></i>
            <span>Entry</span>
            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo $class; ?>">
                 <a href="index.php?file=purchaseentry/list">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"> <i class="fa fa-dot-circle-o sub-icon"></i>Purchase Entry</h4>
                   </div>
                  </a> 
            </li>
            <li class="<?php echo $class; ?>">
                 <a href="index.php?file=salesentry/list">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"><i class="fa fa-dot-circle-o sub-icon"></i>Sales Entry</h4>
                   </div>
                  </a> 
            </li>
            <li class="<?php echo $class; ?>">
                 <a href="index.php?file=paymententry/list">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"><i class="fa fa-dot-circle-o sub-icon"></i>Payment Entry</h4>
                   </div>
                  </a> 
            </li>
          </ul>
        </li>  -->
        
		<li class="treeview">
          <a href="#">
           <i class="fa fa-dashboard icon-1" aria-hidden="true"></i>
            <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right" ></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
                 <a href="index.php">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"><i class="fa fa-dot-circle-o sub-icon"></i>Dashboard</h4>
                   </div>
                  </a> 
            </li>
          </ul>
        </li>
        
         <li class="treeview">
          <a href="#">
           <i class="fa fa-file-code-o icon-1" aria-hidden="true"></i>
            <span>Report</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right" ></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
                 <a href="index.php?file=survey_report/list">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"><i class="fa fa-dot-circle-o sub-icon"></i>Survey Report</h4>
                   </div>
                  </a> 
            </li>
            <li>
                 <a href="index.php?file=areawise_survey_report/list">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"><i class="fa fa-dot-circle-o sub-icon"></i>Areawise Survey Report</h4>
                   </div>
                  </a> 
            </li>
           <!--  <li>
                 <a href="index.php?file=paymentreport/list">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading">Payment Report</h4>
                   </div>
                  </a> 
            </li> -->
          </ul>
        </li>
       <!--  <li class="treeview">
          <a href="#">
            <i class="fa fa-clock-o icon-1" aria-hidden="true"></i>
            <span>Alerts</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right "></i>
            </span>
          </a>
          <ul class="treeview-menu">
           	<li>
                 <a href="index.php?file=alert/stock">
                   <div class="menu-info">
                     <h4 class="control-sidebar-subheading"><i class="fa fa-dot-circle-o sub-icon"></i>Stock Alert</h4>
                   </div>
                  </a> 
            </li>
          </ul>
        </li>  -->       
      </ul>
    </section>
  </aside> 
  </aside> 