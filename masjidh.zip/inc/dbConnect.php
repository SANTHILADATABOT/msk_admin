<?php

$database_username = 'root';
$database_password = '';
$pdo_conn = new PDO( 'mysql:host=localhost;dbname=masjidh_sevai_kuzhu', $database_username, $database_password );
	

?>