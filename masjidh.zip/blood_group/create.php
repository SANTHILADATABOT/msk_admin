    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <small>Add New</small>
		Blood Group        
      </h1>
      
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php?file=blood_group/list"><i class="fa fa-home"></i> Blood Group List</a></li>
        <li class="breadcrumb-item active">Add New</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	 <?php $updateresult='';?>
	 <?php include 'form.php'; ?>
		
	</section>
	<!-- /.content -->
