<script language="javascript" type="text/javascript" src="blood_group/blood_group.js"></script>
<section class="content">
<div class="col">
	<div class="box">
		<!-- /.box-header -->
		<div class="box-body">
			<form class="was-validated"  name="userroll" autocomplete="off">
				<div class="row">
					
                  

					<div class="col-md-6 ">
					<div class="form-group">
					<h5>Blood Group Name  </h5>
					<div class="controls">
					<input type="text" name="blood_group_name" id="blood_group_name" onkeyup="validation(this.id)" class="form-control" required>
					
					</div>

					</div>
                    <div class="form-group">
					<h5>Description </h5>
					<div class="controls">
					<textarea id="description" name="description" style="width:460px;height: 90px;"></textarea>					
					</div>
					
					</div>

					<div class="form-group">
					<h5>Active Status  </h5>
					<div class="controls">
					<select name="status" id="status" class="form-control" required>
					<option value="1">Active</option>
					<option value="0">Inactive</option>
					</select>
					</div>
					</div>

					</div>
				</div>
				<a href="index.php?file=blood_group/list" class="float-left btn btn-primary">Cancel</a>
				<?php if($updateresult==''){?>
				<button type="buton" class="float-right btn btn-success" onclick="blood_group('','Add')">Save</button>
				<?php }else{?>
				<button type="button" class="float-right btn btn-success" onclick="blood_group('<?php echo $updateresult[0]['blood_id'];?>','Update')">Update</button>
				<?php }?>
			</form>
		</div>
		<!-- /.box-body -->
		<div id="userrole_list"></div>
		<div id="distinct_error" style="color:red"></div>
	</div>
</div>
</section>
<?php if($updateresult!=''){?>
<script>
document.getElementById("blood_group_name").value ="<?php echo $updateresult[0]['blood_group_name'];?>";
document.getElementById("description").value ="<?php echo $updateresult[0]['description'];?>";
document.getElementById("status").value ="<?php echo $updateresult[0]['status'];?>";
</script>
<?php } ?>


