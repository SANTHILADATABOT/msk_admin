
    <section class="content-header">
      <h1>
		<small>Add New</small>
		<?php echo ucfirst($foldername); ?>        
      </h1>
	  
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php?file=relationship/list"><i class="fa fa-home"></i> <?php echo ucfirst($foldername); ?> List</a></li>
        <li class="breadcrumb-item active">Add New</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    
	 <?php $updateresult=''?>
     
	 <?php include 'form.php'; ?>
		
	</section>
	<!-- /.content -->
