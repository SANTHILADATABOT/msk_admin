<?php
$current_date=date('Y-m-d');
 ?>
<script language="javascript" type="text/javascript" src="survey_report/survey_report.js"></script>
    
<section class="content-header report-pg" style="background-repeat: no-repeat;background-position: center;background-size: cover;background-image: url(images/top_bg.png);padding: 25px 0px;">
	  <h1>
        <div class="top-left inline-dash">Report<br><span class="welcom inline-welcome">Survey Report </span></div>
      </h1>	  
    </section>
 
    <!-- Main content -->
 <section class="content">
	<div class="row">

		<div class="col-12">
 
			<div class="box">
				<div class="row">
    

    	<div  class="col-lg-3">
    		<h5 class="list-content">Wanted</h5>
    		<select class="form_control select2" id="wanted" name="wanted">
    			<option> Select</option>
    			<option value="Job">Job Wanted</option>
    			<option value="Medical"  >Medical Wanted</option>
    			<option value="Marriage" >Marriage Wanted</option>
    			<option value="MSK" >MSk Join</option>
    		</select>
    	</div>
    	 
    		<div class="go-btn ">
    	 	<a onclick="get_survey_filter_list(wanted.value)" class="hvr-sweep-to-top">Go</a>
    	 </div>
 
</div>
				<!-- /.box-header -->
				<div class="box-body">
					<div class="table-responsive">               
						<table id="example" class="table table-bordered table-hover table-striped display nowrap margin-top-10 w-p100">
							<thead>
								<tr>
									<th>#</th>
									<th>Name</th>
									<th>Mobile Number</th>

									<th>Country Name</th>
									<th>State Name</th>
									<th>District Name</th>
									<th>City Name</th>
 
									<th>Action</th>
								</tr>
							</thead>
							<tbody id="survey_report_list">						
								<?php
//echo "SELECT * FROM fact_finding_form Where entry_date='$current_date' ORDER BY survey_id DESC";
								 $survey = $pdo_conn->prepare("SELECT * FROM fact_finding_form Where entry_date='$current_date' ORDER BY survey_id DESC");
								$survey->execute();
								$survey_list = $survey->fetchall();

								 foreach($survey_list as $value){?>
								
								   <tr>
									<td><?php echo $roll_id;?></td>
									<td><?php echo $value['family_head_name']; ?></td>
									<td><?php echo $value['contact_no']; ?></td>
									<td><?php echo get_country_name($value['country_id']);	?>	</td>
									<td><?php echo get_state_name($value['state_id']); ?></td>
									<td><?php echo  get_district_name($value['district_id']); ?></td>
									<td><?php echo  get_city_name($value['city_id']); ?></td> 
									 
									
								   <td> 
		<!--						  <a href="index.php?file=state/view&state_id=<?php echo $value['state_id']?>" title="Edit"><i class="fa fa-eye" aria-hidden="true"></i></a>  
		-->						  <a href="index.php?file=survey_report/update&survey_report_id=<?php echo $value['survey_report_id']?>" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>  	
								  <a href="#" onclick="del(<?php echo $value['survey_report_id']?>)" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a>
								  
								  </td>
								</tr>
								
								<?php $roll_id+=1;}?>
								
								
							</tbody>				  
			
						</table>
					</div>              
				</div>
				<!-- /.box-body -->
			</div>
			<!-- /.box -->

		</div>
		<!-- /.col -->
	</div>
	<!-- /.row -->
</section>
		<!-- /.content -->
<script type="text/javascript">
	

	function get_survey_filter_list(wanted) {
		
		jQuery.ajax({
	type: "POST",
	url: "survey_report/survey_list.php",
	data: "wanted="+wanted,
	success: function(msg)
	{ 
		alert(msg);
	 $("#survey_report_list").html(msg);
	}
});
	}
</script>