<?php 
include 'inc/dashboardcrud.php';
?>
    <!-- Content Header (Page header) -->
    <section class="content-header" style="background-repeat: no-repeat;background-position: center;background-size: cover;background-image: url(images/wp26208622.jpg);height: 150px;">
      <h1>
        <small></small>
		<?php echo ucfirst($foldername); ?>        
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><div class="top-left">Dashboard<br><span class="welcom">Welcome Administrator</span></div></li>
        <li class="breadcrumb-item active"><?php echo ucfirst($foldername); ?></li>
      </ol>
    </section>

	<section class="content main-admin">
	
	<div class="row">
    	
				
						
				
				<div class="col-xl-3 col-md-6 col-12">
						          <div class="info-box bg-b-orange">
						            <span class="info-box-icon push-bottom"><i class="fa fa-hand-o-up new-dash "></i></span>
						            <div class="info-box-content">
						              <span class="info-box-text">Rights</span>
						              <span class="info-box-number">0</span>
						              <div class="progress">
						                <div class="progress-bar" style="width: 45%"></div>
						              </div>
						              <span class="progress-description">
						                    View More
						                  </span>
						            </div>
						            <!-- /.info-box-content -->
						          </div>
						          <!-- /.info-box -->
						        </div>
								
								
								<div class="col-xl-3 col-md-6 col-12">
						          <div class="info-box bg-b-purple">
						            <span class="info-box-icon push-bottom"><i class="fa fa-bar-chart new-dash "></i></span>
						            <div class="info-box-content">
						              <span class="info-box-text">Survey Form</span>
						              <span class="info-box-number">0</span>
						              <div class="progress">
						                <div class="progress-bar" style="width: 45%"></div>
						              </div>
						              <span class="progress-description">
						                    View More
						                  </span>
						            </div>
						            <!-- /.info-box-content -->
						          </div>
						          <!-- /.info-box -->
						        </div>
				
			
				
		
      </div>
	</section>
	
	

	