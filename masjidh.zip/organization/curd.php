<?php

require_once('../inc/dbConnect.php');

/************************************* INSERT ********************************************/

if($_POST['action']=="Add")
{
	$select_organization=$pdo_conn->prepare("SELECT COUNT(organization_id) FROM organization WHERE organization_type LIKE '".$_POST['organization_type']."' ");
    $select_organization->execute();
    $organization = $select_organization->fetchAll();

	if($organization[0]['COUNT(organization_id)']==0)
	{
		$sql = "INSERT INTO organization(organization_type,description,status) VALUES (:organization_type,:description,:status)";
		$pdo_statement = $pdo_conn->prepare($sql);
			
		$result = $pdo_statement->execute(array(':organization_type'=>$_POST['organization_type'],':description'=>$_POST['description'],':status'=>$_POST['status']));
	}
	else
	{
		echo "error";
	}
	if (!empty($result) )
	{
	  echo $msg = "Successfully Created";
	}	
}

/************************************* UPDATE ********************************************/
if($_POST['action']=="Update")
{
	$select_organization=$pdo_conn->prepare("SELECT COUNT(organization_id) FROM organization WHERE organization_type LIKE '".$_POST['organization_type']."' AND organization_id!='".$_POST['organization_id']."'");
    $select_organization->execute();
    $organization = $select_organization->fetchAll();

	if($organization[0]['COUNT(organization_id)']==0)
	{
		$pdo_statement=$pdo_conn->prepare("update organization set organization_type='".$_POST['organization_type']."',description='".$_POST['description']."',status='".$_POST['status']."' where organization_id=".$_POST['organization_id']);
		$result = $pdo_statement->execute();
	}
	else
	{
		echo "error";
	}
	if(!empty($result)) {
		echo $msg = "Successfully Updated";
	}
}

/************************************* DELETE ********************************************/

if($_POST['action']=="Delete")
{	
	$pdo_statement="DELETE FROM organization where organization_id=".$_POST['organization_id'];
	$result=$pdo_conn->exec($pdo_statement);
	if(!empty($result)) 
	{
		echo $msg = "Successfully Deleted";
	}	
}

?>