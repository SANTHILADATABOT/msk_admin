<?php 
error_reporting(0); 
include ("../inc/commonfunction.php");

$survey = $pdo_conn->prepare("SELECT * FROM fact_finding_form WHERE survey_id='".$_GET['survey_id']."' ");
$survey->execute();
$record = $survey->fetch();
?>
<table width="100%" cellspacing="0" cellpadding="0">
        <tr>
			<td width="20px"><a href="../index.php"><img src="../images/logo.png" alt="image description" height="100px" class="style5"></a></td>
			<td align="center" style="font-size:20px"><b>Survey Report View</b></td>
		</tr>
</table>
<hr>	
<table>


	<tr>
<td>
<td><b>Family No :</b></td><td> <?php echo $record['family_no'] ?></td>
<td><b>Mohalla No: </b></td> <td><?php echo $record['mohalla_no'] ?></td>
<td><b>Aadhar No :</b></td><td> <?php echo $record['aadhar_no'] ?></td>

</td>
</tr>
<tr>
	<td>
		<td></td>
<td> </td>
<td></td>
</td>
</tr>
<tr>
<td>
<td><b>Nagar :</b></td><td> <?php echo $record['street_name'] ?></td>
<td><b>Date :</b></td><td> <?php echo $record['date'] ?></td>


<td><b>Contact No :</b></td><td> <?php echo $record['contact_no'] ?></td>
</td>
</tr>
<tr>
	<td>
<td><b>Mother Tongue :</b></td><td>  <?php echo $record['mother_tongue'] ?></td>


<td><b> Ration Card No :</b></td><td>   <?php echo $record['ration_card_no'] ?></td> 


<td><b>House :</b>
</td>
<td> <?php echo $record['house'] ?>
</td>
</td>
</tr>
<tr>
<td>

<td><b>Bathroom Availability :</b>
</td> 
<td><?php echo $record['bathroom_availability'] ?>
</td>

<td><b>Economic Status :
</b></td> 
<td><?php echo $record['economic_status'] ?>
</td>



<td><b>Gender :</b></td><td> <?php echo $record['gender'] ?></td>
</td>
</tr>
<tr>
<td>
<td><b>Age :</b></td><td> <?php echo $record['age'] ?></td>
<td><b>Relationship :</b></td><td> <?php echo $record['relationship'] ?></td>
<td><b>Education Qualification :</b> </td><td><?php echo $record['edu_qualification'] ?></td>
</td>
</tr>
<tr>
	<td>
<td><b>Marital Status </b></td><td> <?php echo $record['marital_status'] ?></td>


<td><b>Voter id :</b></td><td> <?php echo $record['voter_id'] ?></td>
<td><b>Bussiness Occupation :</b></td><td> <?php echo $record['bussiness_occupation'] ?></td>

</td>
</tr>
<tr>
	<td>
<td><b>Work Location :</b></td><td> <?php echo $record['work_location'] ?></td>
<td><b>Blood Group :</b></td><td> <?php echo $record['blood_group'] ?></td>


<td><b> Children (Age 4 to 15) / Adults (Age Above 15) for Maktab :</b></td><td> <?php echo $record['for_maktab'] ?></td>
</td>
</tr>
<tr>
	<td>

<td><b> Children/ Adults :</b></td><td> <?php echo $record['child_adult_for_maktab'] ?></td>
<td><b> Age :</b></td><td> <?php echo $record['child_adult_for_maktab_age'] ?></td>
<td><b> Why does he/she miss Maktab? : </b></td><td><?php echo $record['miss_maktab'] ?></td>
</td>
</tr>

<tr>
	<td>
<td> <b>Interested in Allin Hifz Course :</b> </td><td><?php echo $record['allin_hifz_course'] ?></td>

<td> <b>Interested in Niswan :</b></td><td> <?php echo $record['interest_in_niswan'] ?></td>
<td><b> Family Women interested in 1-year Muslim Course :</b></td><td> <?php echo $record['family_women_interest_in_1yr_muslim_course'] ?></td>
</td>
</tr>
<td>
	<tr>
		<td>

<td><b> Interested in Niswan :</b></td><td> <?php echo $record['interest_in_niswan'] ?></td>
<td><b>2.Family Member Name:</b></td><td> <?php echo $record['family_member_name_2'] ?></td>


<td><b>3.Family Member Name :</b></td><td> <?php echo $record['family_member_name_3'] ?></td>

</td>
</tr>
<tr>
<td>
<td><b>4.Family Member Name :</b></td><td> <?php echo $record['family_member_name_4'] ?></td>
<td><b>5.Family Member Name :</b> </td><td><?php echo $record['family_member_name_5'] ?></td>
<td><b>6.Family Member Name :</b> </td><td><?php echo $record['family_member_name_6'] ?></td>
</td>
</tr>
<tr>
<td>
<td><b>7.Family Member Name :</b> </td><td><?php echo $record['family_member_name_7'] ?></td>
<td><b>8.Family Member Name :</b></td><td> <?php echo $record['family_member_name_8'] ?></td>
<td><b>9.Family Member Name :</b></td><td> <?php echo $record['family_member_name_9'] ?></td>
</td>
</tr>
<tr>
<td>

<td><b>Old Age Pension :</b></td><td> <?php echo $record['Old Age Pension'] ?></td>
<td><b>Deserted Women pension :</b></td><td> <?php echo $record['deserted_women_pension'] ?></td>
<td><b>Marriage help :</b> </td><td><?php echo $record['marriage_help_msk'] ?></td>

</td>
</tr>
<tr>
<td>
<td><b>Marriage help :</b> </td><td><?php echo $record['marriage_help_radio'] ?></td>
<td><b>Disability Pension :</b></td><td> <?php echo $record['disability_pension'] ?></td>
<td><b>Widow / Aged unmarried welfare :</b></td><td> <?php echo $record['widow_aged_welfare'] ?></td>
</td>
</tr>
<tr>
<td>
<td><b>Destitute / Orphan welfare :</b> </td><td><?php echo $record['destitute_orphan_welfare'] ?></td>
<td><b>Incapable of working :</b></td><td> <?php echo $record['incapable_of_working'] ?></td>
<td><b>Ulama welfare card Details:</b></td><td> <?php echo $record['ulama_welfare_card_details'] ?></td>
</td>
</tr>
<tr>
<td>
<td><b>ulama welfare card :</b></td><td> <?php echo $record['ulama_welfare_card'] ?></td>
<td><b>Others Details :</b></td><td> <?php echo $record['other_details_1_entry'] ?></td>
<td><b>Other Details:</b></td><td> <?php echo $record['other_details_1'] ?></td>
</td>
</tr>
<tr>
<td>
<td><b>Incapable of working :</b></td><td> <?php echo $record['other_details_1'] ?></td>


<td><b>Higher Education Guidance :</b></td> <td><?php echo $record['higher_edu_guide'] ?></td>
<td><b>Financial Support for Education :</b></td><td> <?php echo $record['fin_support_for_edu'] ?></td>
</td>
</tr>
	<tr>
<td>
<td><b>School Dropouts Interested in Employment :</b></td><td> <?php echo $record['school_dropouts_interest_in_emp
'] ?></td>
<td><b>Pre-Matric Scholarship  :</b></td><td> <?php echo $record['pre_matric_scholarship'] ?></td>
<td><b>Post_Matric Scholarship : </b></td><td><?php echo $record['post_matric_scholarship'] ?></td>
</td>
	</tr>
	<tr>
<td>
<td><b>Guidance for Employment :</b></td><td> <?php echo $record['guide_for_emp'] ?></td>
<td><b>Others Details Entry :</b></td><td> <?php echo $record['other_details_2'] ?></td>
<td><b>Others Details  :</b> </td><td><?php echo $record['other_details_entry2'] ?></td>
</td>
</tr>
<tr>
<td>
<td><b>Family Counselling :</b></td><td> <?php echo $record['family_counselling'] ?></td>
<td><b>Nikkah Counselling :</b></td><td> <?php echo $record['nikkah_counselling'] ?></td>


<td>
<b>Entrepreneurship Counselling :</b></td>
<td>
 <?php echo $record['entrepreneur_counselling'] ?></td>

</td>
</tr>
	<tr>
		<td>
<td><b>
Business Counselling :</b></td>
<td>
 <?php echo $record['business_counselling'] ?></td>


	
		<td><b>
Skill Development Guidance & Training :</b></td>
<td>
 <?php echo $record['guide_for_skill_develop'] ?></td>

<td><b>
Rehabilitation Counselling for Addicts :</b> </td>
<td>
<?php echo $record['rehabilitation_counselling'] ?></td>
</td>
</tr>
	<tr>
<td>
<td>
	<b>
 Suffering due to Interest based loan :</b></td><td>

 <?php echo $record['suffer_from_interest_loan'] ?></td>



<td> <b>Details about the Guidance & Counselling :</b></td><td> <?php echo $record['suffer_from_interest_loan'] ?></td>
<td><b> Suffering due to Interest based loan :</b></td><td> <?php echo $record['guide_counselling_full_details'] ?></td>
</td>
</tr>
	<tr>
<td>
<td><b>Others :</b></td><td> <?php echo $record['other_details_3'] ?></td>

<td> <b>Disease Details :</b></td><td> <?php echo $record['disease_details'] ?></td>
<td> <b>Disease Details :</b></td><td> <?php echo $record['disease_no'] ?></td>
</td>
</tr>
		<tr>
<td>
<td>
 <b>Surgery Details (Hospital Cost, Cash in Hand) :</b></td>
<td>
 <?php echo $record['surgery_details'] ?></td>
 
<td>
 <b> Surgery Details :</b></td>
<td>
 <?php echo $record['surgery_details_no'] ?></td>


 <td><b>Have you recoverd from any chronic diseases? If yes, Details of Doctor & Cost of treatment (This is for Guiding others) :</b></td><td> <?php echo $record['recovered_from_chronic_details'] ?></td>
</td>
</tr>
	<tr>
<td>
<td> <b>Monthly Expenditure on Medicine :</b></td><td> <?php echo $record['mon_exp_on_medicine'] ?></td>
<td><b>Monthly Expenditure :</b></td><td> <?php echo $record['mon_exp_on_medicine_no'] ?></td>

<td><b>Availability of Govt.Health Insurance Card :</b></td><td> <?php echo $record['govt_insurance_card_avail'] ?></td>
</td>
</tr>
	<tr>
<td>
<td> <b>Are you willing to financially help those who are suffering in your Mohalla? :</b></td><td> <?php echo $record['willing_to_help_in_mohalla'] ?></td>
<td> <b>Are you willing to financially help those who are suffering in your Mohalla? :</b></td><td> <?php echo $record['willing_to_help_in_mohalla'] ?></td>

<td><b>Are you Interested to serve in the Mohalla Sevai Kuzhu? : </b></td><td><?php echo $record['interest_to_serve_msk_no'] ?></td>
</td>
</tr>
	<tr>
<td>
<td><b>Emergency :</b> </td><td><?php echo $record['emergency_no'] ?></td>
<td><b>Family member who provided information :</b></td><td> <?php echo $record['information_provided_by'] ?><td>
</td>
</tr>

<tr>
	<td>
		<td><b>Country Name:</b></td><td><?php echo get_country_name($record['country_id']);?></td>
		<td><b>State Name:</b></td><td><?php echo get_state_name($record['state_id']);?></td>
		<td><b>District Name:</b></td><td><?php echo get_district_name($record['district_id']);?></td>
		
</td>
</tr>
<tr>
	<td>
	<td><b>City Name:</b></td><td><?php echo get_city_name($record['city_id']); ?>
	</td>
	</td>
</tr>
<!-- <tr>
	<td><b>Emergency No:</b></td><td><?php echo $record['emergency_no'] ?></td>
	<td>
	</td>
</tr> -->

</table>