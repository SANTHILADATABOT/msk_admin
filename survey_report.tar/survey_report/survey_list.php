<?php 
error_reporting(0); 
include ("../inc/commonfunction.php");
 $wanted=$_POST['wanted'];
 

$query='';

if($wanted=='Job')
{ 
	$query='   and guide_for_emp!=""';
}

else if($wanted=='Medical')
{
	$query='   and disease_details!=""';
}

else if($wanted=='Marriage')
{
	$query='   and marriage_help!=""';
}

else if($wanted=='MSK')
{
	$query='   and interested_to_serve!=""';
}
//echo "query".$query;
 	 
?>
 
 <?php 
 echo "SELECT * FROM fact_finding_form WHERE delete_status!='1' $query ORDER BY survey_id DESC";
	$survey = $pdo_conn->prepare("SELECT * FROM fact_finding_form WHERE delete_status!='1' $query ORDER BY survey_id DESC");
	$survey->execute();
	$survey_list = $survey->fetchall();

	foreach($survey_list as $value){?>

	   <tr>
		<td><?php echo $roll_id;?></td>
		<td>
		<?php if($wanted=='MSK')
		{ 
			if($value['interest_to_serve_msk_no']=='1')
			{
				echo $value['family_head_name'];
			}
			else if($value['interest_to_serve_msk_no']=='2')
			{
				echo $value['family_member_name_2'];
			}
			else if($value['interest_to_serve_msk_no']=='3')
			{
				echo $value['family_member_name_3'];
			}
			else if($value['interest_to_serve_msk_no']=='4')
			{
				echo $value['family_member_name_4'];
			}
			else if($value['interest_to_serve_msk_no']=='5')
			{
				echo $value['family_member_name_5'];
			}
			else if($value['interest_to_serve_msk_no']=='6')
			{
				echo $value['family_member_name_6'];
			}
			else if($value['interest_to_serve_msk_no']=='7')
			{
				echo $value['family_member_name_7'];
			}
			else if($value['interest_to_serve_msk_no']=='8')
			{
				echo $value['family_member_name_8'];
			}
			else if($value['interest_to_serve_msk_no']=='9')
			{
				echo $value['family_member_name_9'];
			}  
		} ?>

		<?php if($wanted=='Job')
		{   
			if($value['guide_for_emp']=='1')
			{
				echo $value['family_head_name'];
			}
			else if($value['guide_for_emp']=='2')
			{
				echo $value['family_member_name_2'];
			}
			else if($value['guide_for_emp']=='3')
			{
				echo $value['guide_for_emp'];
			}
			else if($value['guide_for_emp']=='4')
			{
				echo $value['family_member_name_4'];
			}
			else if($value['guide_for_emp']=='5')
			{
				echo $value['family_member_name_5'];
			}
			else if($value['guide_for_emp']=='6')
			{
				echo $value['family_member_name_6'];
			}
			else if($value['guide_for_emp']=='7')
			{
				echo $value['family_member_name_7'];
			}
			else if($value['guide_for_emp']=='8')
			{
				echo $value['family_member_name_8'];
			}
			else if($value['guide_for_emp']=='9')
			{
				echo $value['family_member_name_9'];
			} 
		} ?>

		<?php if($wanted=='Medical')
		{    
			if($value['disease_no']=='1')
			{
				echo $value['family_head_name'];
			}
			else if($value['disease_no']=='2')
			{
				echo $value['family_member_name_2'];
			}
			else if($value['disease_no']=='3')
			{
				echo $value['family_member_name_2'];
			}
			else if($value['disease_no']=='4')
			{
				echo $value['family_member_name_4'];
			}
			else if($value['disease_no']=='5')
			{
				echo $value['family_member_name_5'];
			}
			else if($value['disease_no']=='6')
			{
				echo $value['family_member_name_6'];
			}
			else if($value['disease_no']=='7')
			{
				echo $value['family_member_name_7'];
			}
			else if($value['disease_no']=='8')
			{
				echo $value['family_member_name_8'];
			}
			else if($value['disease_no']=='9')
			{
				echo $value['family_member_name_9'];
			} 
		} ?>
		<?php if($wanted=='Marriage')
		{   
			if($value['marriage_help']=='1')
			{
				echo $value['family_head_name'];
			}
			else if($value['marriage_help']=='2')
			{
				echo $value['family_member_name_2'];
			}
			else if($value['marriage_help']=='3')
			{
				echo $value['guide_for_emp'];
			}
			else if($value['marriage_help']=='4')
			{
				echo $value['family_member_name_4'];
			}
			else if($value['marriage_help']=='5')
			{
				echo $value['family_member_name_5'];
			}
			else if($value['marriage_help']=='6')
			{
				echo $value['family_member_name_6'];
			}
			else if($value['marriage_help']=='7')
			{
				echo $value['family_member_name_7'];
			}
			else if($value['marriage_help']=='8')
			{
				echo $value['family_member_name_8'];
			}
			else if($value['marriage_help']=='9')
			{
				echo $value['family_member_name_9'];
			} 
		} ?>
	 
			</td>
	    <td><?php echo $value['contact_no']; ?></td>
		<td><?php echo get_country_name($value['country_id']);	?>	</td>
		<td><?php echo get_state_name($value['state_id']); ?></td>
		<td><?php echo  get_district_name($value['district_id']); ?></td>
		<td><?php echo  get_city_name($value['city_id']); ?></td> 
		<td><?php echo  get_area_name($value['area_id']); ?></td>
	    <td> 
  	 	<a onclick="survey_view('<?php echo $value['survey_id']  ?>')" title="view"><i class="fa fa-eye" aria-hidden="true"></i>
   		</a>   
   	<!--	<a href="#" title="View" id="quotation_view_modal" onclick="survey_view('<?php echo $value['survey_id'] ?>')" data-toggle="modal" data-target="#quotation_view"><i class="fa fa-eye" aria-hidden="true"></i></a>  -->

   
  		</td>
	</tr>
						
	<?php $roll_id+=1;}
	?>
 
	
									
						
						
						
				 
			 