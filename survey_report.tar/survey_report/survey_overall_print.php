
<style type="text/css">
.style1 {font-weight:normal;font-family:calibri;font-size: 14px;}
.style2 {font-weight:normal;font-family:calibri;font-size: 16px;}
.style3 {font-weight:bold; text-align:right;font-family:calibri;font-size: 12px;}
.style4 {font-weight:bold; font-family:calibri;font-size: 16px;}
.style5 {font-family:calibri;font-weight: bold;font-size: 18px;}
.style6 {font-family:calibri;font-weight: bold;font-size: 16px;}
.style10{ border-top: solid 1px; border-top-color:#BFBFBF;}
.bottom{ border-bottom: solid 1px; border-bottom-color:#BFBFBF;}
.right{ border-right: solid 1px; border-bottom-color:#BFBFBF;}
</style>
<?php 
error_reporting(0);
session_start();
include ("../inc/commonfunction.php");

$cur_date=date('Y-m-d');

$wanted_data=$_REQUEST['wanted_data'];

$query='';

if($wanted_data=='Job')
{ 
	$query='   and fff.guide_for_emp!=""';
}

else if($wanted_data=='Medical')
{
	$query='   and fff.disease_details!=""';
}

else if($wanted_data=='Marriage')
{
	$query='   and fff.marriage_help!=""';
}

else if($wanted_data=='MSK')
{
	$query='   and fff.interested_to_serve!=""';
}
//echo "<br>query-->".$query;
 	 
?>
 
 <?php 

 /*echo "<br>SELECT ffs.family_head_name,ffs.age,ffs.educ_qualification_inp,ffs.marital_status,fff.survey_id,fff.family_no,fff.contact_no,fff.marriage_help_radio,fff.surgery_details,
 fff.guide_for_emp,fff.disease_details,fff.marriage_help_radio,fff.interested_to_serve,fff.business_counselling FROM fact_finding_form as fff Join fact_finding_subform as ffs on fff.unique_no=ffs.random_no WHERE 
 fff.delete_status!='1' $query ORDER BY fff.survey_id DESC";*/
	$survey = $pdo_conn->prepare("SELECT ffs.family_head_name,ffs.age,ffs.educ_qualification_inp,ffs.marital_status,fff.survey_id,fff.family_no,fff.contact_no,fff.marriage_help_radio,fff.surgery_details,
 fff.guide_for_emp,fff.disease_details,fff.marriage_help_radio,fff.interested_to_serve,fff.business_counselling FROM fact_finding_form as fff Join fact_finding_subform as ffs on fff.unique_no=ffs.random_no WHERE 
 fff.delete_status!='1' $query ORDER BY fff.survey_id DESC");
	$survey->execute();
	$survey_list = $survey->fetchall();//echo "<pre>";print_r($survey_list);echo "</pre>";

?>

	

<div id="daybook_report_prints">
	<table width="100%" cellspacing="0" cellpadding="0">
        <tr>
		<?php 
		if($wanted_data=="Job")
		{?>
			<td height="37" align="center" class="style5"><?php echo $wanted_data;?> Needy</td><?php
		}
		else if($wanted_data=="Marriage")
		{?>
			<td height="37" align="center" class="style5"><?php echo $wanted_data;?> Help Needy</td><?php
		}
		else if($wanted_data=="Medical")
		{?>
			<td height="37" align="center" class="style5"><?php echo $wanted_data;?> Surgery Needy</td><?php
		}
		else if($wanted_data=="MSK")
		{?>
			<td height="37" align="center" class="style5">MSK Volunteers</td><?php
		}	
		else 
		{?>
			<td height="37" align="center" class="style5">Survey Report Details</td><?php
		}	
		?>
		
        </tr>
	</table>
	
    <table width="100%" cellspacing="0" cellpadding="0">
	
	  <tr>
            <td width="5%" height="27" align="center" class="style10 style4 right"><strong>S.No</strong></td>
            <td width="6%" align="center" class="style10 style4 right"><strong>&nbsp;F.No</strong></td>
			<td width="10%" align="center" class="style10 style4 right"><strong>&nbsp;Name</strong></td>
			<?php 
			if($wanted_data=="Job" || $wanted_data=="Marriage" || $wanted_data=="MSK")
			{?>
             <td width="8%" align="center" class="style10 style4 right"><strong>&nbsp;Age</strong></td><?php
			}?>
			<?php 
			if($wanted_data=="Job" || $wanted_data=="MSK")
			{?>
            <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Education</strong></td><?php
			}?>
			<?php 
			if($wanted_data=="Marriage")
			{?>
            <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Government & Private</strong></td><?php
			}?>
			<?php 
			if($wanted_data=="Medical")
			{?>
            <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Disease Surgery</strong></td>
			<td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Approximate Cost</strong></td><?php
			}?>
			<?php 
			if($wanted_data=="MSK")
			{?>
            <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Job or Business</strong></td><?php
			}?>
            <td width="14%" align="center" class="style10 style4 right"><strong>&nbsp;Phone No</strong></td>
			<td width="8%" align="center" class="style10 style4 right"><strong>&nbsp;Apply</strong></td>  
			
	  </tr>
        <tr>
			<?php
			if($wanted_data=='MSK')
			{?>
				<td height="0" colspan="8" align="center" class="style10 style3 right" ></td><?php
			}
			else
			{?>
				<td height="0" colspan="7" align="center" class="style10 style3 right" ></td><?php
			}?>
        </tr>
        <?php 
	
		
	
foreach ($survey_list as $record)
{
	$fno = $record['family_no'];
	$family_name = $record['family_head_name'];
	$age = $record['age'];
	$education=$record['educ_qualification_inp'];
	$govt = $record['marriage_help_radio'];
	$disease = $record['surgery_details'];
	$cost = $record['surgery_details'];
	$contact_no = $record['contact_no'];
	$business_counselling=$record['business_counselling'];
?>
	
	<tr>
            	<td align="center" height="25" class="style2 right"><?php echo $i = $i+1; ?></td>
                <td align="center" class="style2 right">&nbsp;<?php echo $fno;?></td>
                <td align="left" class="style2 right">&nbsp;<?php echo $family_name; ?></td>
                <?php 
				if($wanted_data=="Job" || $wanted_data=="Marriage" || $wanted_data=="MSK")
				{?>
					<td align="center" class="style2 right">&nbsp;<?php echo $age; ?></td><?php
				}?>
				<?php 
				if($wanted_data=="Job" || $wanted_data=="MSK")
				{?>
					<td align="center" class="style2 right">&nbsp;<?php echo $education; ?></td><?php
				}?>
				<?php 
				if($wanted_data=="Marriage")
				{?>
					<td align="center" class="style2 right">&nbsp;<?php echo $govt; ?></td><?php
				}?>
				<?php 
				if($wanted_data=="Medical")
				{?>
					<td align="left" class="style2 right">&nbsp;<?php echo $disease; ?></td>
					<td align="left" class="style2 right">&nbsp;<?php //echo "Cost"; ?></td><?php
				}?>
				<?php 
				if($wanted_data=="MSK")
				{?>
					<td align="left" class="style2 right"><?php echo $business_counselling; ?></td><?php
				}?>
                <td align="center" class="style2 right"><?php echo $contact_no; ?></td>
                <td align="left" class="style2 right"><?php //echo "Apply";?></td>
				
	</tr>
		   <?php
	 
}	
?>
			<?php
			if($wanted_data=='MSK')
			{?>
				<td colspan="8" align="right" class="style10 style1" >Printed Date :<?php echo $curdate=date('d-m-Y');?></td><?php
			}
			else
			{?>
				<td colspan="7" align="right" class="style10 style1" >Printed Date :<?php echo $curdate=date('d-m-Y');?></td><?php
			}?>
            
	
     
    </table>
</div>